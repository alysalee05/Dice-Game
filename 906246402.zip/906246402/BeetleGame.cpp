//
//  BeetleGame.cpp
//

#include "Beetle.h"
#include "BeetleGame.h"
#include "BeetleDrawing.h"

#include <iostream>

namespace cs31
{

BeetleGame::BeetleGame() : mHuman(), mComputer(), mHumanDie(), mComputerDie()
{
    
}

// draw the board by using a BeetleDrawing to draw the two Beetles
std::string BeetleGame::display( std::string msg ) const
{
    BeetleDrawing drawing( mHuman, mComputer );
    std::string result = drawing.draw() + "\n" + msg;
    return( result );
}


// TODO when amount is zero, it is a random roll...
// otherwise, an amount value is a cheating value...
void BeetleGame::humanRoll( int amount )
{
    if (amount == 0){
        mHumanDie.roll();
    }
    else
        mHumanDie.setValue(amount);
}

// TODO return the value of the Human's die
int BeetleGame::getHumanDie( ) const
{
    return mHumanDie.getValue();
}

// TODO convert the Human's die value to a Beetle's body part
// then depending on the body part involved, enforce the game ordering of body parts:
// - namely, body before everything else and head before eyes or antenna
// if allowed, build the desired body part on the Human's beetle
// if a body part was successfully built, return true
// otherwise, return false
bool BeetleGame::humanPlay( )
{
    int dieVal = getHumanDie();
    return makePlay(mHuman, dieVal);
}

bool BeetleGame::makePlay(Beetle &beetle, int dieVal)
{
    switch (dieVal){
        case 1:
            if (beetle.hasEye2() || !beetle.hasHead()){
                return false;
            }
            if (beetle.hasEye1()){
                beetle.buildEye();
                return true;
            }
            beetle.buildEye();
            return true;
            
        case 2:
            if(beetle.hasAntenna2() || !beetle.hasHead()) {
                return false;
            }
            if (beetle.hasAntenna1()){
                beetle.buildAntenna();
                return true;
            }
            beetle.buildAntenna();
            return true;

        case 3:
        // checks for body, checks if it has leg 1/2/3/4
            if (beetle.hasLeg4() || !beetle.hasBody()){
                return false;
            }
            // beetle.buildLeg();
            // return true;
            if (beetle.hasLeg3()){
                beetle.buildLeg();
                return true;
            }
            if (beetle.hasLeg2()){
                beetle.buildLeg();
                return true;
            }
            if (beetle.hasLeg1()){
                beetle.buildLeg();
                return true;
            }
            beetle.buildLeg();
            return true;

        case 4:
            if (beetle.hasTail() || !beetle.hasBody()){
                return false;
            }
            beetle.buildTail();
            return true;
                
        case 5:
        // if it has a body, it can have a head/builds the head/otherwise, doesn't
            if (beetle.hasHead() || !beetle.hasBody()){
                return false;
            }
            beetle.buildHead();
            return true;
            
        case 6:
            if (beetle.hasBody()){
                return false;
            }
            beetle.buildBody();
            return true;
    }
    return false;
}

// TODO when amount is zero, it is a random roll...
// otherwise, an amount value is a cheating value...
void BeetleGame::computerRoll( int amount )
{
    if (amount == 0){
       mComputerDie.roll();
    }
    else
        mComputerDie.setValue(amount);
}

// TODO return the value of the Computer's die
int BeetleGame::getComputerDie( ) const
{
    return mComputerDie.getValue();
}

// TODO convert the Computer's die value to a Beetle's body part
// then depending on the body part involved, enforce the game ordering of body parts:
// - namely, body before everything else and head before eyes or antenna
// if allowed, build the desired body part on the Computer's beetle
// if a body part was successfully built, return true
// otherwise, return false
bool BeetleGame::computerPlay( )
{
    int dieVal = getComputerDie();
    return makePlay(mComputer, dieVal);
}

// TODO what is the current state of the game
BeetleGame::GameOutcome  BeetleGame::determineGameOutcome( ) const
{
    if(mHuman.isComplete()){
        return BeetleGame::GameOutcome::HUMANWONGAME;
    }
    //added else
    if (mComputer.isComplete()){
        return BeetleGame::GameOutcome::COMPUTERWONGAME;
    }
    return BeetleGame::GameOutcome::GAMENOTOVER;
}

std::string  BeetleGame::stringifyGameOutcome( ) const
{
    std::string result = "";
    switch( determineGameOutcome() )
    {
        case GameOutcome::COMPUTERWONGAME:
            result = "Computer Won!";
            break;
        case GameOutcome::HUMANWONGAME:
            result = "Human Won!";
            break;
        case GameOutcome::GAMENOTOVER:
            result = "Game Not Over!";
            break;
    }
    return( result );
}

// TODO has the game ended with a winner?
bool BeetleGame::gameIsOver() const
{
    BeetleGame::GameOutcome result = determineGameOutcome();
    return result != GameOutcome::GAMENOTOVER;
}


Beetle BeetleGame::getHumanBeetle( ) const
{
    return( mHuman );
}

Beetle BeetleGame::getComputerBeetle( ) const
{
    return( mComputer );
}

}


